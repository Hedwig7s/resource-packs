Returns the classic feel to Minecraft :D 

CREDITS: 

Mojang, 
especially jeb, notch, junkboy, Johan A, Ninni L, BombBoy, Martin J, and Markus K 
 - for the original textures. 

Sencie - atmosphere (optifine) 
 - https://www.planetminecraft.com/texture-pack/old-lighting-amp-old-water/ 
jack.wyl - minecon drowned overlay recreation. beacon model. bugfixing 
Crackers0106 - help with soulsoil and raw copper block 
fayer3 - improved cloud shader
InfiniteVoid - tulips 
DartCat25 - 2D item
 - https://github.com/DartCat25/resourcepacks/tree/main/2d%20items
Swunglepord862 - ported plank pattern

HONOURABLE MENTIONS: 

Swunglepord862 
 - for bug reporting, suggestions, and lots of support. 
PoeticRainbow 
 - Inspiration, brainstorming, and competition. 
Bainill0 
 - Inspiration and helpful criticism. 
co2_
 - Helpful criticism and testing. 
Guardian1502 
 - Inspiration. 
Godlander 
 - Shader education 
HexyFrostPlays
 - being cool :)
Slicedlime 
 - For thoroughly documenting texture changes between versions. 
 
Everyone who's ever written a bug report or made a suggestion; 
and you, for supporting the pack. 

Everyone who supports the pack - Thanks so much. 

